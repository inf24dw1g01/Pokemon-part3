export * from './ping.controller';
export * from './pokemon.controller';
export * from './trainer.controller';
export * from './teams.controller';
export * from './tipo.controller';

export * from './pokemon.model';
export * from './teams.model';
export * from './trainer.model';
export * from './tipo.model';

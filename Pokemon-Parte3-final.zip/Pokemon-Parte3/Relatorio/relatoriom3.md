### Relatório Completo - Desenvolvimento Web 1

---

## **1. Introdução**
Este relatório descreve uma aplicação desenvolvida no contexto da disciplina **Desenvolvimento Web 1**, focada na gestão de Pokémon, treinadores, equipas e tipos. A aplicação utiliza React no frontend e uma base de dados estruturada em MySQL, com suporte a um ambiente Dockerizado para execução padronizada.

---

## **2. Arquitetura Geral do Sistema**

O sistema combina:

1. **Frontend**:
   - Desenvolvido com React, utilizando `react-admin` para interfaces administrativas.
   - Modularidade nos componentes como `PokemonList` e `TipoList`.

2. **Backend**:
   - Uma API RESTful que interage com uma base de dados MySQL.
   - Implementa controladores para operações CRUD (Create, Read, Update, Delete).

3. **Base de Dados**:
   - Estruturada para armazenar informações sobre Pokémon, treinadores, tipos e equipas.

4. **Ambiente de Desenvolvimento**:
   - Docker e Docker Compose para criar e gerenciar containers.
   - Testes automatizados via Postman para garantir a integridade da API.

---

## **3. Detalhamento do Frontend**

### **3.1. Estrutura dos Componentes React**
- **`App.js`**:
  - Configura o `react-admin` com um provedor de dados LoopBack 4.
  - Gerencia recursos como Pokémon, Treinadores, Equipas e Tipos.

- **`PokemonList.js`**:
  - Exibe uma lista de Pokémon que tem relação com os tipos de cada pokemon.
  - Campos: `id`, `name`, `tipo1` e `tipo2`.
- **`TeamList.js`**:
  - Lista equipas de Pokémon.
  - Campos: `id`, `name`.
- **`TipoList.js`**:
  - Exibe uma lista de Tipos de pokemon.
  - Campos: `id`, `name`.
- **`TrainerList.js`**:
  - Exibe uma lista de Treinadores.
  - Campos: `id`, `name`.

### **3.2. Estilo e Usabilidade**
- **`index.css`**:
  - Estilos globais simples para fonte e suavização.
  - Recomenda-se expansão para melhor personalização.

- **Funcionalidades Futuras**:
  - Implementar filtros e paginação no `Datagrid`.
  - Adicionar validações para entradas de dados.

---

## **4. Base de Dados**

### **4.1. Estrutura**
O banco de dados é organizado em tabelas específicas para armazenar informações relacionadas aos Pokémon e suas interações:

- **`pokemon`**:
  - Campos: `id`, `name`, `tipo1`, `tipo2`.
  - Exemplo de dado: `1`,`Pikachu`, `Electric`,`NULL`.
  - Relaciona pokemon a tipos.

- **`trainer`**:
  - Campos: `id`, `name`.
  - Exemplo de dado: `1`,`Ash Ketchum`.

- **`tipo`**:
  - Campos: `id`, `name`.
  - Exemplo de dado: `1`,`Fire`.

- **`team`**:
  - Campos: `id`, `team`.
  - Exemplo de dado: `1` ,`Equipa1`.

### **4.2. Relacionamentos**
- Relacionamento de 1 para muitos, como `pokemon.tipo1` e `pokemon.tipo2` ↔ `tipo.id`, em que um pokemon tem dois tipos, tipo1 e tipo2 que se interligam ao id da tabela Tipo.
---

## **5. Ambiente Dockerizado**

### **5.1. Configuração**
- **Containers**:
  - `db`: Banco de dados MySQL.
  - `api`: Aplicação Node.js.

- **Comandos**:
  - Iniciar ambiente: `docker-compose up`.
  - API disponível em `http://localhost:3000`.

---

## **6. Testes Automatizados**

### **6.1. Postman**
- Testes CRUD para Pokémon, Treinadores, Equipas e Tipos.
- Exemplo:
  - **POST /pokemon**:
    ```json
    {
      "id":1,
      "nome": "Charmander",
      "tipo1": "Fire",
      "tipo2": null
    }
    ```

### **6.2. Resultados**
- Validação do funcionamento de endpoints.
- Deteção de inconsistências e melhorias.
- Problemas identificados nos métodos Get,Post,Put,Delete.
 Exemplo:
  - GET/pokemon: Esperado retornar uma lista de Pokémon, mas a resposta foi um erro 500(Internal Server Error).
- Foi observado que nos relacionamentos estava a dar erros sendo que as foreign keys na base de dados estavam corretas.
---
### **6.3 Tentativas de Solução
- Foi feita uma migração na base de dados em que foi observado um problema, em que a base de dados estava identificar o nome como name e então teve que ser mudado.
- Foram vistos os modelos e repositórios do LoopBack 4, para garantir que os recursos estavam corretamente definidos para a base de dados MySQL.
- Nos relacionamentos foi verificado que nos controllers era feito apenas a do tipo2 em vez de ser a do tipo1 acabando por acrescentar tanto o relacionamento do tipo1 como a do tipo2 
![controllers](<Captura de Ecrã (14).png>)


## **7. Observações e Melhorias Sugeridas**

### **7.1. Segurança**
- A senha `12345678` da base de dados é fraca e deve ser substituída.

### **7.2. Normalização de Dados**
- Resolver duplicatas na tabela `tipo` para evitar redundância.

### **7.3. Funcionalidades Futuras**
1. **Relacionamentos Avançados**:
   - Relacionar equipas e treinadores diretamente com Pokémon.
   - Exemplo: Criar tabelas `trainer_pokemon` ou `teams_trainers`.

2. **Melhorias na Interface**:
   - Implementar filtros e pesquisas em tempo real no frontend.

3. **Escalabilidade**:
   - Adicionar suporte a internacionalização (i18n) no frontend.
   - Testes de carga no backend.

4. **Segurança no Backend**:
   - Implementar autenticação JWT para proteger endpoints sensíveis.

---

## **8. Conclusão**

A aplicação oferece uma base sólida para gerenciar informações de Pokémon, treinadores, tipos e equipas. Com melhorias propostas, o sistema poderá ser ampliado para atender casos de uso mais complexos, mantendo a modularidade e eficiência.


### **9. Melhorias Futuras**

1. **Filtros e Paginação no Frontend**:  
   - Adicionar filtros dinâmicos e paginação no `Datagrid` para facilitar a navegação e manipulação de grandes volumes de dados.

2. **Segurança no Backend**:  
   - Implementar autenticação JWT para proteger endpoints e substituir a senha fraca da base de dados por uma mais segura armazenada em variáveis de ambiente.

3. **Normalização da Base de Dados**:  
   - Resolver duplicatas na tabela `tipo` para evitar redundância e inconsistências nos dados.


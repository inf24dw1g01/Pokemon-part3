Drop schema if exists `pokemon`;
Create schema pokemon;
use pokemon;
DROP TABLE IF EXISTS `Tipo`;

CREATE TABLE `Tipo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

LOCK TABLES `Tipo` WRITE;

UNLOCK TABLES;

DROP TABLE IF EXISTS `Pokemon`;

CREATE TABLE `Pokemon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `tipo1` int,
  `tipo2` int,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`tipo1`) REFERENCES `Tipo`(`id`),
  FOREIGN KEY (`tipo2`) REFERENCES `Tipo`(`id`)
);


LOCK TABLES `Pokemon` WRITE;

UNLOCK TABLES;


DROP TABLE IF EXISTS `Teams`;

CREATE TABLE `Teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  PRIMARY KEY (`id`)
);



LOCK TABLES `Teams` WRITE;

UNLOCK TABLES;


DROP TABLE IF EXISTS `Trainer`;

CREATE TABLE `Trainer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

LOCK TABLES `Trainer` WRITE;

UNLOCK TABLES;


insert into `Teams` (`name`) values ("Equipa 1");
insert into `Teams` (`name`) values ("Equipa 2");
insert into `Teams` (`name`) values ("Equipa 3");
insert into `Teams` (`name`) values ("Equipa 4");
insert into `Teams` (`name`) values ("Equipa 5");
insert into `Teams` (`name`) values ("Equipa 6");
insert into `Teams` (`name`) values ("Equipa 7");
insert into `Teams` (`name`) values ("Equipa 8");
insert into `Teams` (`name`) values ("Equipa 9");
insert into `Teams` (`name`) values ("Equipa 10");
insert into `Teams` (`name`) values ("Equipa 11");
insert into `Teams` (`name`) values ("Equipa 12");
insert into `Teams` (`name`) values ("Equipa 13");
insert into `Teams` (`name`) values ("Equipa 14");
insert into `Teams` (`name`) values ("Equipa 15");
insert into `Teams` (`name`) values ("Equipa 16");
insert into `Teams` (`name`) values ("Equipa 17");
insert into `Teams` (`name`) values ("Equipa 18");
insert into `Teams` (`name`) values ("Equipa 19");
insert into `Teams` (`name`) values ("Equipa 20");
insert into `Teams` (`name`) values ("Equipa 21");
insert into `Teams` (`name`) values ("Equipa 22");
insert into `Teams` (`name`) values ("Equipa 23");
insert into `Teams` (`name`) values ("Equipa 24");
insert into `Teams` (`name`) values ("Equipa 25");
insert into `Teams` (`name`) values ("Equipa 26");
insert into `Teams` (`name`) values ("Equipa 27");
insert into `Teams` (`name`) values ("Equipa 28");
insert into `Teams` (`name`) values ("Equipa 29");
insert into `Teams` (`name`) values ("Equipa 30");

insert into `Trainer`(`name`) values ("ASH");
insert into `Trainer`(`name`) values ("RED");
insert into `Trainer`(`name`) values ("MISTY");
insert into `Trainer`(`name`) values ("BROCK");
insert into `Trainer`(`name`) values ("GARY");
insert into `Trainer`(`name`) values ("DAWN");
insert into `Trainer`(`name`) values ("SERENA");
insert into `Trainer`(`name`) values ("MAY");
insert into `Trainer`(`name`) values ("IRIS");
insert into `Trainer`(`name`) values ("TRACEY");
insert into `Trainer`(`name`) values ("LANCE");
insert into `Trainer`(`name`) values ("CYNTHIA");
insert into `Trainer`(`name`) values ("STEVEN");
insert into `Trainer`(`name`) values ("BLUE");
insert into `Trainer`(`name`) values ("LEAF");
insert into `Trainer`(`name`) values ("ALAIN");
insert into `Trainer`(`name`) values ("GLADION");
insert into `Trainer`(`name`) values ("N");
insert into `Trainer`(`name`) values ("LYSANDRE");
insert into `Trainer`(`name`) values ("LILLIE");
insert into `Trainer`(`name`) values ("HOP");
insert into `Trainer`(`name`) values ("MILO");
insert into `Trainer`(`name`) values ("RAIHAN");
insert into `Trainer`(`name`) values ("BLAINE");
insert into `Trainer`(`name`) values ("KOGA");
insert into `Trainer`(`name`) values ("SABRINA");
insert into `Trainer`(`name`) values ("ERIKA");
insert into `Trainer`(`name`) values ("JANINE");
insert into `Trainer`(`name`) values ("BRUNO");
insert into `Trainer`(`name`) values ("WALLACE");
insert into `Trainer`(`name`) values ("FLANNERY");
insert into `Trainer`(`name`) values ("CLAIR");
insert into `Trainer`(`name`) values ("AGATHA");

insert into `Tipo` (`name`) values ("Water");
insert into `Tipo` (`name`) values ("Fire");
insert into `Tipo` (`name`) values ("Dark");
insert into `Tipo` (`name`) values ("Ice");
insert into `Tipo` (`name`) values ("Steel");
insert into `Tipo` (`name`) values ("Dragon");
insert into `Tipo` (`name`) values ("Rock");
insert into `Tipo` (`name`) values ("Ground");
insert into `Tipo` (`name`) values ("Grass");
insert into `Tipo` (`name`) values ("Fighting");
insert into `Tipo` (`name`) values ("Poison");
insert into `Tipo` (`name`) values ("Dark");
insert into `Tipo` (`name`) values ("Fairy");
insert into `Tipo` (`name`) values ("Ghost");
insert into `Tipo` (`name`) values ("Electric");
insert into `Tipo` (`name`) values ("Bug");
insert into `Tipo` (`name`) values ("Flying");
insert into `Tipo` (`name`) values ("Fire");
insert into `Tipo` (`name`) values ("Water");
insert into `Tipo` (`name`) values ("Normal");
insert into `Tipo` (`name`) values ("Psychic");
insert into `Tipo` (`name`) values ("Ice");
insert into `Tipo` (`name`) values ("Steel");
insert into `Tipo` (`name`) values ("Dragon");
insert into `Tipo` (`name`) values ("Rock");
insert into `Tipo` (`name`) values ("Ground");
insert into `Tipo` (`name`) values ("Grass");
insert into `Tipo` (`name`) values ("Fighting");
insert into `Tipo` (`name`) values ("Poison");
insert into `Tipo` (`name`) values ("Bug");
insert into `Tipo` (`name`) values ("Normal");
insert into `Tipo` (`name`) values ("Psychic");
insert into `Tipo` (`name`) values ("Ghost");
insert into `Tipo` (`name`) values ("Poison");
insert into `Tipo` (`name`) values ("Electric");
insert into `Tipo` (`name`) values ("Bug");
insert into `Tipo` (`name`) values ("Normal");
insert into `Tipo` (`name`) values ("Psychic");
insert into `Tipo` (`name`) values ("Fairy");
insert into `Tipo` (`name`) values ("Flying");


insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Charizard", 2, 38);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Pikachu", 33, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Absol", 3, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Vaporean", 1, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Deoxys", 37, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Jigglypuff", 36, 38);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Snorlax", 30, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Gengar", 33, 32);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Shedinja", 35, 32);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Bulbasaur", 9, 33);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Charmander", 2, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Squirtle", 1, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Pidgeotto", 30, 18);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Sandshrew", 8, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Zubat", 33, 18);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Oddish", 9, 33);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Meowth", 30, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Machamp", 11, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Magnemite", 17, 6);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Onix", 7, 8);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Cubone", 8, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Hitmonlee", 11, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Jynx", 4, 37);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Mew", 37, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Eevee", 30, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Ditto", 30, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Togepi", 12, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Houndoom", 3, 2);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Lugia", 37, 18);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Rayquaza", 6, 18); 
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Torterra", 9, 8);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Piplup", 1, null);
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Luxray", 33, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Garchomp", 6, 8); 
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Lucario", 11, 6); 
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Weavile", 3, 4); 
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Gallade", 37, 11);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Arceus", 30, null);  
insert into `Pokemon` (`name`, `tipo1`, `tipo2`) values ("Greninja", 1, 3);  

GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY '12345678'
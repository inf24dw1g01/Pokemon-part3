import {
  repository,
} from '@loopback/repository';
import {
  param,
  get,
  getModelSchemaRef,
} from '@loopback/rest';
import {
  Pokemon,
  Tipo,
} from '../models';
import {PokemonRepository} from '../repositories';

export class PokemonTipoController {
  constructor(
    @repository(PokemonRepository)
    public pokemonRepository: PokemonRepository,
  ) { }

  @get('/pokemon/{id}/tipo1', {
    responses: {
      '200': {
        description: 'Tipo belonging to Pokemon',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Tipo),
          },
        },
      },
    },
  })
  async getTipo1(
    @param.path.number('id') id: typeof Pokemon.prototype.id,
  ): Promise<Tipo> {
    return this.pokemonRepository.tipo1Id(id);
  }
  
  @get('/pokemon/{id}/tipo2', {
    responses: {
      '200': {
        description: 'Tipo belonging to Pokemon',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Tipo),
          },
        },
      },
    },
  })
  async getTipo2(
    @param.path.number('id') id: typeof Pokemon.prototype.id,
  ): Promise<Tipo> {
    return this.pokemonRepository.tipo2Id(id);
  }
}

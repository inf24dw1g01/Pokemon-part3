import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, BelongsToAccessor} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Pokemon, PokemonRelations, Tipo} from '../models';
import {TipoRepository} from './tipo.repository';

export class PokemonRepository extends DefaultCrudRepository<
  Pokemon,
  typeof Pokemon.prototype.id,
  PokemonRelations
> {

  public readonly tipo1Id: BelongsToAccessor<Tipo, typeof Pokemon.prototype.id>;

  public readonly tipo2Id: BelongsToAccessor<Tipo, typeof Pokemon.prototype.id>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('TipoRepository') protected tipoRepositoryGetter: Getter<TipoRepository>,
  ) {
    super(Pokemon, dataSource);
    this.tipo2Id = this.createBelongsToAccessorFor('tipo2Id', tipoRepositoryGetter,);
    this.registerInclusionResolver('tipo2Id', this.tipo2Id.inclusionResolver);
    this.tipo1Id = this.createBelongsToAccessorFor('tipo1Id', tipoRepositoryGetter,);
    this.registerInclusionResolver('tipo1Id', this.tipo1Id.inclusionResolver);
  }
}

export * from './pokemon.repository';
export * from './teams.repository';
export * from './tipo.repository';
export * from './trainer.repository';

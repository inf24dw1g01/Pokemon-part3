import {Entity, model, property, belongsTo} from '@loopback/repository';
import {Tipo} from './tipo.model';

@model()
export class Pokemon extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @belongsTo(() => Tipo, {name: 'tipo1Id'})
  tipo1: number;

  @belongsTo(() => Tipo, {name: 'tipo2Id'})
  tipo2: number;

  constructor(data?: Partial<Pokemon>) {
    super(data);
  }
}

export interface PokemonRelations {
  // describe navigational properties here
}

export type PokemonWithRelations = Pokemon & PokemonRelations;

import { Datagrid, List, TextField, EditButton, ReferenceField,DeleteButton} from 'react-admin';

export const PokemonList = () => (
    <List>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="name" />
                <ReferenceField source="tipo1" reference="tipos">
                    <TextField source="name"/>
                </ReferenceField>
                <ReferenceField source="tipo2" reference="tipos">
                    <TextField source="name"/>
                </ReferenceField>
                <EditButton />
                <DeleteButton />
        </Datagrid>
    </List>
);